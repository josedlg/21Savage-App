import java.util.Comparator;


public class MergeSortThreads extends Thread {


	public static <T> void sort(T[] x, Comparator<? super T> comp, int threads) {
		MergeSortThreads(x, 0, x.length-1, comp, threads);
	}
              
	     public static <T> void mergeSort(T[] x, int first, int last, Comparator<? super T > comp) { 
	    	 if(first == last) {
	    		 return;
	    	 }
	    	 if(last - first >0 ) {
	    		 int middle = (first + last) / 2;
	    		 
	    		 mergeSort(x,first, middle,comp);
	    		 mergeSort(x,middle + 1,last,comp);
	    		 merge(x,middle,last,comp);
	    		 
	    	 }
	     }
	     
	     private <T> MergeSortThreads(T[] x,int first, int last, Comparator<? super T> comp, int availableThreads) {
	    	if(last - first > 0) { 
	    		if(availableThreads <= 1) {
	    			mergeSort(x,first,last,comp);
	    		}
	    		else {
	    			int middle = last/2;
	    					Thread firstHalf = new Thread() {
	    				public void run() {
	    					MergeSortThreads(x,middle +1, last ,comp, availableThreads -1  );
	    				}
	    					};
	    					firstHalf.start();
                            secoundHalf.start();
                            
                            try {
                            	firstHalf.join();
                            }catch (InterruptedException ie) {
                            	ie.printStackTrace();
                            }
                            merge(x,first,middle,last,comp);
	    		}
	    	}
	       
}
	     private static <T> void merge(T[] x,int first,int mid, int last, Comparator<? super T> comp) {
	    	 int n = last - first +1;
	    	 
	    	 Object[] a = new Object[n];
	    	 
	    	 int e1 = first;
	    	 
	    	 int e2 = mid +1;
	    	 
	    	 int j = 0;
	    	 
	    	 while(e1<= mid && e2 <= last) {
	    		 if(comp.compare(x[e1],x[e2])< 0){
	    			 a[j]=x[e1];
	    			 e1++;
	    		 }else {
	    			 a[j]= x[e2];
	    			 e2++;
	    		 }
	    		 j++;
	    			 
	    		 }
	    	 
	     do {
	    	 a[j] = x[e1];
	    	 e1++;
	    	 j++;
	     } while (e1 <= mid);

	     
	     do {
	    	 a[j] = x[e2];
	    	 e2++;
	    	 j++;
	     } while (e2 <= last);
	     
	     for (j = 0; j< n ;j++) {
	    	 x[first + j] = (T) a[j];
	     }
}


}
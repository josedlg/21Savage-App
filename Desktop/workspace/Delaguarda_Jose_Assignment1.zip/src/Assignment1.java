import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

public class Assignment1 {

	public static void main(String[] args) {
		RunElements();
	}
	public static void RunElements() {
		int SIZE = 100,
		TIMES = 20,
		availableThreads = (Runtime.getRuntime().availableProcessors())*2;
		
		Number [] = x;
		
		Comparator<Number> comp = new Comparator<Number>() {
			public int compare(Number e1, String e2) {
				return e1.compareTo(e2);
			}

			@Override
			public int compare(Number o1, Number o2) {
				// TODO Auto-generated method stub
				return 0;
			}
		};
		System.out.printf("These are the max number of threads ", availableThreads);
		for(int i =1; i <= availableThreads; i*=2) {
			if(i == 1) {
				System.out.printf("Thread: ",i);
			}else {
				System.out.printf("Thread:", i);
			}
			
			for(int j = 0 , k = SIZE; j < TIMES; ++j,k*=2) {
				x = randomArray(y);
				
				long begins = System.currentTimeMillis();
				MergeSortThreads.sort(x, comp, availableThreads);
			    long ends= System.currentTimeMillis();
			    
			    if(! isSorted(x, comp)) {
			    	throw new RuntimeException("not sorted aftward:" +Arrays.toString(x));
			    }
			    System.out.printf("10d elements  =>  %6d ms ", k, ends - begins );
				
			}
			System.out.print("\n");
			
		}
	}
	
	public static Integer[] randomArray(int length) {
        Integer[] a = new Integer[length];
        Random rand = new Random(System.currentTimeMillis());
        for (int i = 0; i < a.length; i++) {
            a[i] = rand.nextInt(1000000);
        }
        return a;
    }

public static <T> void shuffle(T[] x) {
    for (int i = 0; i < x.length; i++) {
        // move element i to a random index in [i .. length-1]
        int randomIndex = (int) (Math.random() * x.length - i);
        swap(x, i, i + randomIndex);

}
}
public static final <T> void swap(T[] x, int i, int j) {
    if (i != j) {
        T temp = x[i];
        x[i] = x[j];
        x[j] = temp;
    }
}

public static <T> boolean isSorted(T[] x, Comparator<? super T> comp) {
    for (int i = 0; i < x.length - 1; i++) {
        if (comp.compare(x[i], x[i + 1]) > 0) {
            System.out.println(x[i] + " > " + x[i + 1]);
            return false;
        }
    }
    return true;
}

}
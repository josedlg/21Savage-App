import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		String Line;
		
		URLParser par = new URLParser();
		Scanner input = new Scanner(System.in);
		while(true) {
			Line = input.nextLine();
			par.SetArg(Line);
		}

	}

}

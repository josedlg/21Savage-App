import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class URLParser {
	   public void parseCommandLine(String command) throws Exception {
//		    -i do input
//		    -o  out
		        String[] args = command.split(" ");
		        if (args.length != 2) {
		            System.out.println("Exact two args");
		            return;
		        }
		        String flag = args[0].trim();
		        String file = args[1];
		        if (flag.equals("-i")) {
		            readFile(file);
		            return;

		        }

		        if (flag.equals("-o")) {
		            writeURLInfo(file);
		            return;
		        }

		        System.out.println(flag + " is not a valid flag");

		    }
	   private void writeURLInfo(String file) throws Exception {
	         PrintWriter writeOut;
	        try {
	            writeOut = new PrintWriter(file);
	            if (URLsExist()) {
	                return;
	            }
	            for (String url : urls) {
	                ArrayList<String> urLinfo = getURLInfo(url);
	                for ( String line :  urLinfo){
	                    writeOut.println(line);

	                }
	               writeOut.println("\n\n\n\n\n---------NEXT URL----------\n\n\n\n\n");

	            }
	            writeOut.close();
	        } catch (IOException e) {
	            System.out.println(e.getLocalizedMessage());

	        }

	    }

	
	            
	            ArrayList<String> getURLImage(String address) throws Exception{
	            	File outputImageFile = null;
	            	URL url = null;
	            	BufferedImage image = null;
	            	
	            	image = ImageIO.read(url);
	            	//
	            	//URLConnection uc = url.openConnection();
	            	ArrayList<String> info = new ArrayList<>();

	       

	            	ImageIO.write(image, "jpg", outputImageFile);
	            	return info;
	            	
	            }
                ArrayList<String> getURLInfo(String address) throws Exception{
                	URL url = null;
                	
                	url = new URL(address);
                	URLConnection uc = url.openConnection();
                	
                	ArrayList<String> info = new ArrayList<>();
                	System.out.println(uc.getURL().toExternalForm() + ":");

                	System.out.println(" Content Type: " + uc.getContentType());

                	System.out.println(" Content Length: " + uc.getContentLength());

                	System.out.println(" Last Modified: " + new Date(uc.getLastModified()));

                	System.out.println(" Expiration: " + uc.getExpiration());

                	System.out.println(" Content Encoding: " + uc.getContentEncoding());
                	return info;
                }
                private ArrayList<String> urls = null;

                public void SetArg(String arg) throws Exception {
                    arg = arg.trim();
                    parseCommandLine(arg);
                }
                private boolean URLsExist() {
                    boolean r = urls == null || urls.size() == 0;
                    if (r) {
                        String info = "not urls exist, please do -i first";
                        System.out.println(info);
                    }
                    return r;
                }
                private void readFile(String adress) {
                    adress = adress.replaceAll("/", "//");
                    File file = new File(adress);
                    if (!file.exists()) {
                        System.out.println(adress + " does not exist");
                        return;
                    }

                    try {
                        Scanner input = new Scanner(new FileReader(file));
                        urls = new ArrayList<>();
                        String line = null;
                        while (input.hasNextLine()) {
                            line = input.nextLine();
                            urls.add(line);
                        }
                        input.close();

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }


                }

                
}
